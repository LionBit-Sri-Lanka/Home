# main_libs
  
  This library contains the pin definition of the Lion:Bit Development Board. 
  
  ```   
  pinMode(D4, OUTPUT);
    
    Example:
    
    #define D4      (16)    /* I/O   U2RX  GPIO16, HS1_DATA4, U2RXD, EMAC_CLK_OUT */
    
 ```
 
 
